<?php
  
  
  $DB_HOST="";
  $DB_USER="";
  $DB_PASS="";
  $DB_NAME="";

  $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);


$sql='Select count(*) as total from BOOKING';
$result=mysqli_query($conn,$sql);
$numOfRow=mysqli_fetch_assoc($result);

if(!empty($_POST)){
  $id='B'.$numOfRow++;
  $name=trim($_POST['name']);
  $email=trim($_POST['email']);
  $phone=trim($_POST['phone']);
  $date->trim($_POST['date']);
  $time->trim($_POST['time']);
  $people->$_POST['people'];
  $message->trim( $_POST['message']);


$sql = 'INSERT INTO event(id,name, email, phone, date, time, people, message) VALUES (?,?,?,?,?,?,?,?)';
            $smt = $conn->prepare($sql);
            $smt->bind_param('ssssssis',$id,$name, $email, $phone, $date, $time, $people, $message); 
            $smt->execute();

}

?>
<?php 
$query="SELECT * FROM event WHERE id=$id";
$result=mysqli_query($conn,$query);

$row=mysql_fetch_array($result);

$nameSelect=$row["name"];
$emailSelect=$row["email"];
$phoneSelect=$row["phone"];
$dateSelect=$row["date"];
$timeSelect=$row["time"];
$peopleSelect=$row["people"];
$messageSelect=$row["message"];

?>







