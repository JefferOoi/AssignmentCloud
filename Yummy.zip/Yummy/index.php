

<!DOCTYPE html>
<html lang="en">

<head>
    
    
    
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Face2Face Noodle</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,600;1,700&family=Amatic+SC:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&family=Inter:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">


</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top d-flex align-items-center">
    <div class="container d-flex align-items-center justify-content-between">

      <a href="index.html" class="logo d-flex align-items-center me-auto me-lg-0">
        <h1>Face2Face Noodle House<span>.</span></h1>
      </a>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a href="#hero">Home</a></li>
          <li><a href="#about">About</a></li>
          <li><a href="#menu">Menu</a></li>
          <li><a href="#chefs">News</a></li>
          <li><a href="#gallery">Gallery</a></li>
       
        </ul>
      </nav><!-- .navbar -->

      <a class="btn-book-a-table" href="confirmBooking.php">Book a Table</a>
      <i class="mobile-nav-toggle mobile-nav-show bi bi-list"></i>
      <i class="mobile-nav-toggle mobile-nav-hide d-none bi bi-x"></i>

    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="hero d-flex align-items-center section-bg">
    <div class="container">
      <div class="row justify-content-between gy-5">
        <div class="col-lg-5 order-2 order-lg-1 d-flex flex-column justify-content-center align-items-center align-items-lg-start text-center text-lg-start">
          <h2 data-aos="fade-up">Enjoy Your Food<br>Delicious Food</h2>
          <p data-aos="fade-up" data-aos-delay="100">Book a table now for our MOUTH WATERING Tranditional Sarawak Noodles (dry). </p>
          <div class="d-flex" data-aos="fade-up" data-aos-delay="200">
            <a href="confirmBooking.php" class="btn-book-a-table">Book a Table</a>
          </div>
        </div>
        <div class="col-lg-5 order-1 order-lg-2 text-center text-lg-start">
          <img src="assets/img/Traditional-Sarawak-Noodles-(dry).jpg" class="img-fluid" alt="" data-aos="zoom-out" data-aos-delay="300">
        </div>
      </div>
    </div>
  </section><!-- End Hero Section -->

  <main id="main">

    <!-- ======= About Section ======= -->
    <section id="about" class="about">
      <div class="container" data-aos="fade-up">

        <div class="section-header">
          <h2>About Us</h2>
          <p>Learn More <span>About Us</span></p>
        </div>

        <div class="row gy-4">
          <div class="col-lg-7 position-relative about-img" style="background-image: url(assets/img/wheategg.jpg) ;" data-aos="fade-up" data-aos-delay="150">
            <div class="call-us position-absolute">
              <h4>Book a Table Now!</h4>
              
            </div>
          </div>
          <div class="col-lg-5 d-flex align-items-end" data-aos="fade-up" data-aos-delay="300">
            <div class="content ps-0 ps-lg-5">
              <p class="fst-italic">
                Face to Face Noodle House is more than meets the eye. It’s heritage and history of
                 how it came to be goes back to about a century ago inspired by Jook Sing noodles made by our founder’s great grandfather.
              </p>
              <ul>
                <li><i class="bi bi-check2-all"></i> In 1903, our founder’s great grandfather left China to Hong Kong and acquired the art of making Jook Sing noodles</li>
                <li><i class="bi bi-check2-all"></i> A technique whereby the noodles were made from mixing eggs, flour and other ingredients together by hand and then riding a bamboo log to knead the dough to produce chewy, springy noodles.</li>
                <li><i class="bi bi-check2-all"></i> With the vision of bringing authentic and high quality Sarawak noodles to the masses, we believe in not only creating good food but having sincere “face to face” connections with customers.</li>
              </ul>
              <p>
                As the business expands to accommodate a variety of customer’s tastes, we have diversified our menu to include various 
                interpretations of the Kolok Mee and Pan Mee. Each dish is complemented with different types of hand made sauces, chilli and sambal.
              </p>


                
              </div>
            </div>
          </div>
        </div>

      </div>
    </section><!-- End About Section -->

    <!-- ======= Stats Counter Section ======= -->
    <section id="stats-counter" class="stats-counter">
      <div class="container" data-aos="zoom-out">

        <div class="row gy-4">

          <div class="col-lg-3 col-md-6">
            <div class="stats-item text-center w-100 h-100">
              <span data-purecounter-start="0" data-purecounter-end="8" data-purecounter-duration="1" class="purecounter"></span>
              <p>Locations</p>
            </div>
          </div><!-- End Stats Item -->

          <div class="col-lg-3 col-md-6">
            <div class="stats-item text-center w-100 h-100">
              <span data-purecounter-start="0" data-purecounter-end="24" data-purecounter-duration="1" class="purecounter"></span>
              <p>Dishes</p>
            </div>
          </div><!-- End Stats Item -->

          <div class="col-lg-3 col-md-6">
            <div class="stats-item text-center w-100 h-100">
              <span data-purecounter-start="0" data-purecounter-end="28" data-purecounter-duration="1" class="purecounter"></span>
              <p>Franchises</p>
            </div>
          </div><!-- End Stats Item -->

          <div class="col-lg-3 col-md-6">
            <div class="stats-item text-center w-100 h-100">
              <span data-purecounter-start="0" data-purecounter-end="8" data-purecounter-duration="1" class="purecounter"></span>
              <p>Rating(n/10)</p>
            </div>
          </div><!-- End Stats Item -->

        </div>

      </div>
    </section><!-- End Stats Counter Section -->

    <!-- ======= Menu Section ======= -->
    <section id="menu" class="menu">
      <div class="container" data-aos="fade-up">

        <div class="section-header">
          <h2>Our Menu</h2>
          <p>Check Our <span>Menu</span></p>
        </div>

        <ul class="nav nav-tabs d-flex justify-content-center" data-aos="fade-up" data-aos-delay="200">

          <li class="nav-item">
            <a class="nav-link active show" data-bs-toggle="tab" data-bs-target="#menu-starters">
              <h4>Sarawak Noodles</h4>
            </a>
          </li><!-- End tab nav item -->

          <li class="nav-item">
            <a class="nav-link" data-bs-toggle="tab" data-bs-target="#menu-breakfast">
              <h4>Dry Pan Mee</h4>
            </a><!-- End tab nav item -->

          <li class="nav-item">
            <a class="nav-link" data-bs-toggle="tab" data-bs-target="#menu-lunch">
              <h4>Soup Pan Mee</h4>
            </a>
          </li><!-- End tab nav item -->

          <li class="nav-item">
            <a class="nav-link" data-bs-toggle="tab" data-bs-target="#menu-dinner">
              <h4>Rice Noodle</h4>
            </a>
          </li><!-- End tab nav item -->

        </ul>

        <div class="tab-content" data-aos="fade-up" data-aos-delay="300">

          <div class="tab-pane fade active show" id="menu-starters">

            <div class="tab-header text-center">
              <p>Menu</p>
              <h3>Sarawak Noodles</h3>
            </div>

            <div class="row gy-5">

              <div class="col-lg-4 menu-item">
                <a href="assets/img/sarawaknoodles/Traditional-Sarawak-Noodles-(dry).jpg" class="glightbox"><img src="assets/img/sarawaknoodles/Traditional-Sarawak-Noodles-(dry).jpg" class="menu-img img-fluid" alt=""></a>
                <h4>Traditional Sarawak Noodles (Dry)</h4>
                <p class="price">
                  RM8.00
                </p>
              </div><!-- Menu Item -->

              <div class="col-lg-4 menu-item">
                <a href="assets/img/sarawaknoodles/Traditional-Sarawak-Noodles-(soup).jpeg" class="glightbox"><img src="assets/img/sarawaknoodles/Traditional-Sarawak-Noodles-(soup).jpeg" class="menu-img img-fluid" alt=""></a>
                <h4>Traditional Sarawak Noodles (Soup)</h4>
                <p class="price">
                  RM8.00
                </p>
              </div><!-- Menu Item -->

              <div class="col-lg-4 menu-item">
                <a href="assets/img/sarawaknoodles/Chili Sauce Sarawak Noodles.jpeg" class="glightbox"><img src="assets/img/sarawaknoodles/Chili Sauce Sarawak Noodles.jpeg" class="menu-img img-fluid" alt=""></a>
                <h4>Dark Soy Sauce & Chili Sauce Sarawak Noodles</h4>
                <p class="price">
                  RM8.00
                </p>
              </div><!-- Menu Item -->

              <div class="col-lg-4 menu-item">
                <a href="assets/img/sarawaknoodles/Chili Sauce Sarawak Noodles2.jpeg" class="glightbox"><img src="assets/img/sarawaknoodles/Chili Sauce Sarawak Noodles2.jpeg" class="menu-img img-fluid" alt=""></a>
                <h4>Chili Sauce Sarawak Noodles</h4>
                <p class="price">
                  RM8.00
                </p>
              </div><!-- Menu Item -->

              <div class="col-lg-4 menu-item">
                <a href="assets/img/sarawaknoodles/Dark-Soy-Sauce-Sarawak-Noodles.jpeg" class="glightbox"><img src="assets/img/sarawaknoodles/Dark-Soy-Sauce-Sarawak-Noodles.jpeg" class="menu-img img-fluid" alt=""></a>
                <h4>Dark Soy Sauce Sarawak Noodles</h4>
                <p class="price">
                  RM8.00
                </p>
              </div><!-- Menu Item -->

              <div class="col-lg-4 menu-item">
                <a href="assets/img/sarawaknoodles/Prawn-Pan-Mee-(Soup).jpeg" class="glightbox"><img src="assets/img/sarawaknoodles/Prawn-Pan-Mee-(Soup).jpeg" class="menu-img img-fluid" alt=""></a>
                <h4>Prawn Pan Mee (Soup)</h4>
                <p class="price">
                 RM9.00
                </p>
              </div><!-- Menu Item -->

            </div>
          </div><!-- End Starter Menu Content -->

          <div class="tab-pane fade" id="menu-breakfast">

            <div class="tab-header text-center">
              <p>Menu</p>
              <h3>Dry Pan Mee</h3>
            </div>

            <div class="row gy-5">

              <div class="col-lg-4 menu-item">
                <a href="assets/img/Dry Pan Mee/Creations-Minced-Pork-Mee-(dry).jpeg" class="glightbox"><img src="assets/img/Dry Pan Mee/Creations-Minced-Pork-Mee-(dry).jpeg" class="menu-img img-fluid" alt=""></a>
                <h4>Creations Minced Pork Pan Mee (Dry)</h4>
                <p class="price">
                  RM8.00
                </p>
              </div><!-- Menu Item -->

              <div class="col-lg-4 menu-item">
                <a href="assets/img/Dry Pan Mee/Curry Chicken Pan Mee (Dry).jpg" class="glightbox"><img src="assets/img/Dry Pan Mee/Curry Chicken Pan Mee (Dry).jpg" class="menu-img img-fluid" alt=""></a>
                <h4>Curry Chicken Pan Mee (Dry)</h4>
                <p class="price">
                  RM9.00
                </p>
              </div><!-- Menu Item -->

              <div class="col-lg-4 menu-item">
                <a href="assets/img/Dry Pan Mee/House Specialty Pan Mee (dry).jpg" class="glightbox"><img src="assets/img/Dry Pan Mee/House Specialty Pan Mee (dry).jpg" class="menu-img img-fluid" alt=""></a>
                <h4>House Specialty Pan Mee (Dry)</h4>
                
                <p class="price">
                  RM8.00
                </p>
              </div><!-- Menu Item -->

              <div class="col-lg-4 menu-item">
                <a href="assets/img/Dry Pan Mee/House-Specialty-Hot-Spicy-Pan-Mee-(dry).jpg" class="glightbox"><img src="assets/img/Dry Pan Mee/House-Specialty-Hot-Spicy-Pan-Mee-(dry).jpg" class="menu-img img-fluid" alt=""></a>
                <h4>House Specialty Hot & Spicy Pan Mee (Dry)</h4>
                <p class="price">
                  RM8.00
                </p>
              </div><!-- Menu Item -->

              <div class="col-lg-4 menu-item">
                <a href="assets/img/Dry Pan Mee/Pan-Mee-with-Sesame-Sauce-(Dry).jpeg" class="glightbox"><img src="assets/img/Dry Pan Mee/Pan-Mee-with-Sesame-Sauce-(Dry).jpeg" class="menu-img img-fluid" alt=""></a>
                <h4>Pan Mee with Sesame Sauce (Dry)</h4>
                <p class="price">
                 RM8.00
                </p>
              </div><!-- Menu Item -->

              <div class="col-lg-4 menu-item">
                <a href="assets/img/Dry Pan Mee/Siquan-Piquant-Pan-Mee-(Dry).jpeg" class="glightbox"><img src="assets/img/Dry Pan Mee/Siquan-Piquant-Pan-Mee-(Dry).jpeg" class="menu-img img-fluid" alt=""></a>
                <h4>Sichuan Piquant Pan Mee (Dry)</h4>
                
                <p class="price">
                  RM9.40
                </p>
              </div><!-- Menu Item -->

            </div>
          </div><!-- End Breakfast Menu Content -->

          <div class="tab-pane fade" id="menu-lunch">

            <div class="tab-header text-center">
              <p>Menu</p>
              <h3>Soup Pan Mee</h3>
            </div>

            <div class="row gy-5">

              <div class="col-lg-4 menu-item">
                <a href="assets/img/souppanmee/Chef's Special Pan Mee (Soup).jpg" class="glightbox"><img src="assets/img/souppanmee/Chef's Special Pan Mee (Soup).jpg" class="menu-img img-fluid" alt=""></a>
                <h4>Chef's Special Pan Mee (Soup)</h4>
               
                <p class="price">
                  RM8.00
                </p>
              </div><!-- Menu Item -->

              <div class="col-lg-4 menu-item">
                <a href="assets/img/souppanmee/Curry-Chicken-Pan-Mee-(Soup).jpeg" class="glightbox"><img src="assets/img/souppanmee/Curry-Chicken-Pan-Mee-(Soup).jpeg" class="menu-img img-fluid" alt=""></a>
                <h4>Curry Chicken Pan Mee (Soup)</h4>
                
                <p class="price">
                 RM9.00
                </p>
              </div><!-- Menu Item -->

              <div class="col-lg-4 menu-item">
                <a href="assets/img/souppanmee/Genki-Herbal-Chicken-Pan-Mee-Sua-(Soup).jpeg" class="glightbox"><img src="assets/img/souppanmee/Genki-Herbal-Chicken-Pan-Mee-Sua-(Soup).jpeg" class="menu-img img-fluid" alt=""></a>
                <h4>Genki Herbal Chicken Pan Mee (Soup)</h4>
                <p class="price">
                 RM10.40
                </p>
              </div><!-- Menu Item -->

              <div class="col-lg-4 menu-item">
                <a href="assets/img/souppanmee/House-Specialty-Pan-Mee-(Soup).jpeg" class="glightbox"><img src="assets/img/souppanmee/House-Specialty-Pan-Mee-(Soup).jpeg" class="menu-img img-fluid" alt=""></a>
                <h4>House Specialty Pan Mee (Soup)</h4>
                <p class="price">
                 RM8.00
                </p>
              </div><!-- Menu Item -->

              <div class="col-lg-4 menu-item">
                <a href="assets/img/souppanmee/Loh-Pan-Mee.jpg" class="glightbox"><img src="assets/img/souppanmee/Loh-Pan-Mee.jpg" class="menu-img img-fluid" alt=""></a>
                <h4>Loh Pan Mee</h4>
                <p class="price">
                 RM9.00
                </p>
              </div><!-- Menu Item -->

              <div class="col-lg-4 menu-item">
                <a href="assets/img/souppanmee/Sichuan Piquant Pan Mee (Soup).jpeg" class="glightbox"><img src="assets/img/souppanmee/Sichuan Piquant Pan Mee (Soup).jpeg" class="menu-img img-fluid" alt=""></a>
                <h4>Sichuan Piquant Pan Mee (Soup)</h4>
                <p class="price">
                  RM9.40
                </p>
              </div><!-- Menu Item -->

            </div>
          </div><!-- End Lunch Menu Content -->

          <div class="tab-pane fade" id="menu-dinner">

            <div class="tab-header text-center">
              <p>Menu</p>
              <h3>Rice Noodle</h3>
            </div>

            <div class="row gy-5">

              <div class="col-lg-4 menu-item">
                <a href="assets/img/ricenoodle/Ipoh Hor Fen.jpg" class="glightbox"><img src="assets/img/ricenoodle/Ipoh Hor Fen.jpg" class="menu-img img-fluid" alt=""></a>
                <h4>Ipoh Hor Fen</h4>
                <p class="price">
                  RM9.00
                </p>
              </div><!-- Menu Item -->

              <div class="col-lg-4 menu-item">
                <a href="assets/img/ricenoodle/Penang Char Koay Teow.jpg" class="glightbox"><img src="assets/img/ricenoodle/Penang Char Koay Teow.jpg" class="menu-img img-fluid" alt=""></a>
                <h4>Penang Char Koay Teow</h4>
                <p class="price">
                  RM9.00
                </p>
              </div><!-- Menu Item -->

              <div class="col-lg-4 menu-item">
                <a href="assets/img/ricenoodle/Pepper Soup Bee Hoon.jpg" class="glightbox"><img src="assets/img/ricenoodle/Pepper Soup Bee Hoon.jpg" class="menu-img img-fluid" alt=""></a>
                <h4>Pepper Soup Bee Hoon</h4>
                <p class="price">
                  RM9.90
                </p>
              </div><!-- Menu Item -->

              <div class="col-lg-4 menu-item">
                <a href="assets/img/ricenoodle/Sarawak-Laksa.jpg" class="glightbox"><img src="assets/img/ricenoodle/Sarawak-Laksa.jpg" class="menu-img img-fluid" alt=""></a>
                <h4>Sarawak Laksa</h4>
                <p class="price">
                 RM9.90
                </p>
              </div><!-- Menu Item -->

              <div class="col-lg-4 menu-item">
                <a href="assets/img/ricenoodle/Traditional-Bee-Hoon-(Dry).jpeg" class="glightbox"><img src="assets/img/ricenoodle/Traditional-Bee-Hoon-(Dry).jpeg" class="menu-img img-fluid" alt=""></a>
                <h4>Traditional Bee Hoon (Dry)</h4>
                <p class="price">
                  RM8.00
                </p>
              </div><!-- Menu Item -->

              <div class="col-lg-4 menu-item">
                <a href="assets/img/ricenoodle/Traditional-Bee-Hoon-(Soup).jpeg" class="glightbox"><img src="assets/img/ricenoodle/Traditional-Bee-Hoon-(Soup).jpeg" class="menu-img img-fluid" alt=""></a>
                <h4>Traditional Bee Hoon (Soup)</h4>
                <p class="price">
                 RM9.00
                </p>
              </div><!-- Menu Item -->

            </div>
          </div><!-- End Dinner Menu Content -->

        </div>

      </div>
    </section><!-- End Menu Section -->

    <!-- ======= Testimonials Section ======= -->
    <section id="testimonials" class="testimonials section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-header">
          <h2>Testimonials</h2>
          <p>What Are They <span>Saying About Us</span></p>
        </div>

        <div class="slides-1 swiper" data-aos="fade-up" data-aos-delay="100">
          <div class="swiper-wrapper">

            <div class="swiper-slide">
              <div class="testimonial-item">
                <div class="row gy-4 justify-content-center">
                  <div class="col-lg-6">
                    <div class="testimonial-content">
                      <p>
                        <i class="bi bi-quote quote-icon-left"></i>
                        Proin iaculis purus consequat sem cure digni ssim donec porttitora entum suscipit rhoncus. Accusantium quam, ultricies eget id, aliquam eget nibh et. Maecen aliquam, risus at semper.
                        <i class="bi bi-quote quote-icon-right"></i>
                      </p>
                      <h3>Saul Goodman</h3>
                      <h4>Ceo &amp; Founder</h4>
                      <div class="stars">
                        <i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-2 text-center">
                    <img src="assets/img/testimonials/testimonials-1.jpg" class="img-fluid testimonial-img" alt="">
                  </div>
                </div>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-item">
                <div class="row gy-4 justify-content-center">
                  <div class="col-lg-6">
                    <div class="testimonial-content">
                      <p>
                        <i class="bi bi-quote quote-icon-left"></i>
                        Export tempor illum tamen malis malis eram quae irure esse labore quem cillum quid cillum eram malis quorum velit fore eram velit sunt aliqua noster fugiat irure amet legam anim culpa.
                        <i class="bi bi-quote quote-icon-right"></i>
                      </p>
                      <h3>Sara Wilsson</h3>
                      <h4>Designer</h4>
                      <div class="stars">
                        <i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-2 text-center">
                    <img src="assets/img/testimonials/testimonials-2.jpg" class="img-fluid testimonial-img" alt="">
                  </div>
                </div>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-item">
                <div class="row gy-4 justify-content-center">
                  <div class="col-lg-6">
                    <div class="testimonial-content">
                      <p>
                        <i class="bi bi-quote quote-icon-left"></i>
                        Enim nisi quem export duis labore cillum quae magna enim sint quorum nulla quem veniam duis minim tempor labore quem eram duis noster aute amet eram fore quis sint minim.
                        <i class="bi bi-quote quote-icon-right"></i>
                      </p>
                      <h3>Jena Karlis</h3>
                      <h4>Store Owner</h4>
                      <div class="stars">
                        <i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-2 text-center">
                    <img src="assets/img/testimonials/testimonials-3.jpg" class="img-fluid testimonial-img" alt="">
                  </div>
                </div>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-item">
                <div class="row gy-4 justify-content-center">
                  <div class="col-lg-6">
                    <div class="testimonial-content">
                      <p>
                        <i class="bi bi-quote quote-icon-left"></i>
                        Quis quorum aliqua sint quem legam fore sunt eram irure aliqua veniam tempor noster veniam enim culpa labore duis sunt culpa nulla illum cillum fugiat legam esse veniam culpa fore nisi cillum quid.
                        <i class="bi bi-quote quote-icon-right"></i>
                      </p>
                      <h3>John Larson</h3>
                      <h4>Entrepreneur</h4>
                      <div class="stars">
                        <i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-2 text-center">
                    <img src="assets/img/testimonials/testimonials-4.jpg" class="img-fluid testimonial-img" alt="">
                  </div>
                </div>
              </div>
            </div><!-- End testimonial item -->

          </div>
          <div class="swiper-pagination"></div>
        </div>

      </div>
    </section><!-- End Testimonials Section -->

    

    <!-- ======= Chefs Section ======= -->
    <section id="chefs" class="chefs section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-header">
          <h2>Chefs</h2>
          <p>Our <span>Proffesional</span> Chefs</p>
        </div>

        <div class="row gy-4">

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="100">
            <div class="chef-member">
              <div class="member-img">
                <img src="assets/img/TheStarB.jpg" class="img-fluid" alt="">
              </div>
              <div class="member-info">
                <h4>Fastest Mee Kolot Eater</h4>
                <span>Chia Koh Zheng</span>
                <p>Won RM2,000 and a golden bowl worth RM 998 in the fastest mee kolok eater competition</p>
              </div>
            </div>
          </div><!-- End Chefs Member -->

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="200">
            <div class="chef-member">
              <div class="member-img">
                <img src="assets/img/Spotlite.jpg" class="img-fluid" alt="">
              </div>
              <div class="member-info">
                <h4>Patrick Tse</h4>
                <span>Founder</span>
                <p>"If you crave some noodles, head over to Face2Face noodle hosue for some awesome and budget meals."</p>
              </div>
            </div>
          </div><!-- End Chefs Member -->

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="300">
            <div class="chef-member">
              <div class="member-img">
                <img src="assets/img/ThePopularBookGuide.jpg" class="img-fluid" alt="">
              </div>
              <div class="member-info">
                <h4>William Anderson</h4>
                <span>Featured</span>
                <p>Delicious combintions of mee and rice and various food such as bok choy and roasted chicken</p>
              </div>
            </div>
          </div><!-- End Chefs Member -->

        </div>

      </div>
    </section><!-- End Chefs Section -->

    

    <!-- ======= Gallery Section ======= -->
    <section id="gallery" class="gallery section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-header">
          <h2>gallery</h2>
          <p>Check <span>Our Gallery</span></p>
        </div>

        <div class="gallery-slider swiper">
          <div class="swiper-wrapper align-items-center">
            <div class="swiper-slide"><a class="glightbox" data-gallery="images-gallery" href="assets/img/gallery/gallery-1.jpg"><img src="assets/img/gallery/gallery-1.jpg" class="img-fluid" alt=""></a></div>
            <div class="swiper-slide"><a class="glightbox" data-gallery="images-gallery" href="assets/img/gallery/gallery-2.jpg"><img src="assets/img/gallery/gallery-2.jpg" class="img-fluid" alt=""></a></div>
            <div class="swiper-slide"><a class="glightbox" data-gallery="images-gallery" href="assets/img/gallery/gallery-3.jpg"><img src="assets/img/gallery/gallery-3.jpg" class="img-fluid" alt=""></a></div>
            <div class="swiper-slide"><a class="glightbox" data-gallery="images-gallery" href="assets/img/gallery/gallery-4.jpg"><img src="assets/img/gallery/gallery-4.jpg" class="img-fluid" alt=""></a></div>
            <div class="swiper-slide"><a class="glightbox" data-gallery="images-gallery" href="assets/img/gallery/gallery-5.jpg"><img src="assets/img/gallery/gallery-5.jpg" class="img-fluid" alt=""></a></div>
            <div class="swiper-slide"><a class="glightbox" data-gallery="images-gallery" href="assets/img/gallery/gallery-6.jpg"><img src="assets/img/gallery/gallery-6.jpg" class="img-fluid" alt=""></a></div>
            <div class="swiper-slide"><a class="glightbox" data-gallery="images-gallery" href="assets/img/gallery/gallery-7.jpg"><img src="assets/img/gallery/gallery-7.jpg" class="img-fluid" alt=""></a></div>
            <div class="swiper-slide"><a class="glightbox" data-gallery="images-gallery" href="assets/img/gallery/gallery-8.jpg"><img src="assets/img/gallery/gallery-8.jpg" class="img-fluid" alt=""></a></div>
          </div>
          <div class="swiper-pagination"></div>
        </div>

      </div>
    </section><!-- End Gallery Section --> 


  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">

    <div class="container">
      <div class="row gy-3">
        <div class="col-lg-3 col-md-6 d-flex">
          <i class="bi bi-geo-alt icon"></i>
          <div>
            <h4>Address</h4>
            <p>
              1-1-1, Tingkat Mahsuri 5, 11950,<br> Bayan Lepas, Pulau Pinang.<br>
              
            </p>
          </div>

        </div>

        <div class="col-lg-3 col-md-6 footer-links d-flex">
          <i class="bi bi-telephone icon"></i>
          <div>
            <h4>Reservations</h4>
            <p>
              <strong>Phone:</strong> 0123456789<br>
              <strong>Email:</strong> info@example.com<br>
            </p>
          </div>
        </div>

        <div class="col-lg-3 col-md-6 footer-links d-flex">
          <i class="bi bi-clock icon"></i>
          <div>
            <h4>Opening Hours</h4>
            <p>
              <strong>Mon-Sat: 11AM</strong> - 23PM<br>
              Sunday: Closed
            </p>
          </div>
        </div>

        <div class="col-lg-3 col-md-6 footer-links">
          <h4>Follow Us</h4>
          <div class="social-links d-flex">
            <a href="#" class="twitter"><i class="bi bi-twitter"></i></a>
            <a href="#" class="facebook"><i class="bi bi-facebook"></i></a>
            <a href="#" class="instagram"><i class="bi bi-instagram"></i></a>
            <a href="#" class="linkedin"><i class="bi bi-linkedin"></i></a>
          </div>
        </div>

      </div>
    </div>

    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong><span>Face 2 Face Noodle House</span></strong>. All Rights Reserved
      </div>
      <div class="credits">
      </div>
    </div>

  </footer><!-- End Footer -->
  <!-- End Footer -->

  <a href="#" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>



  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>